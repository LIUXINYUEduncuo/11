﻿namespace 贪吃蛇
{
    public interface ISenceUpdate
    {
        void Update();
    }
}