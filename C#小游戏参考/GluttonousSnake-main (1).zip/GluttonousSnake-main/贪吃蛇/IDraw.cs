﻿namespace 贪吃蛇
{
    public interface IDraw
    {
        void Draw();
    }
}