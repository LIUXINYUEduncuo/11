﻿using System;

namespace 贪吃蛇
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            
            
            Game game = new Game();
            game.Start();
        }
    }
}